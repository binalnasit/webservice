//  dataVc.swift
//  Created by binal on 03/02/19.

import UIKit
class dataVc: UIViewController {
    
    performSegue(withIdentifier: "SegueToscreen name", sender: indexPath)
    
    if(segue.identifier == "SegueToscreen name")
    {
    
    let data = segue.destination as! ViewControllername
    
    if let indexPath = sender as? IndexPath{
    let senderid = array[indexPath.row]
    
    data.strSendId = pass data name
    
    ///////////////////////// Table view cell animation////////////////
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
    cell.alpha = 0.0
    let transform = CATransform3DTranslate(CATransform3DIdentity, -250 , 20 , 0)
    cell.layer.transform = transform
    UIView.animate(withDuration: 2.0) {
    cell.alpha = 1.0
    cell.layer.transform = CATransform3DIdentity
    }
    }
    ///////////////imageset///////////////////
    
    func setImage() {
    let dataProfile  = userInfo["image"] as? String
    
    let imageURL = URL(string: (WebserviceURLs.kBaseImageURL + (dataProfile ?? "")))
    self.imgProfiale.sd_setShowActivityIndicatorView(true)
    self.imgProfile.layer.cornerRadius = self.imgProfile.frame.width/2
    self.imgProfile.clipsToBounds = true
    self.lblName.text = userInfo["fullname"] as? String
    self.imgProfile.sd_setImage(with: imageURL, placeholderImage: UIImage.init(named: "imgname"), options: []) { (image, error, cacheType, url) in
    self.imgProfile.sd_removeActivityIndicator()
    }
    }
    
    
    ////////////////////////////////////////// web service file //////////////////////////////////////
    //  Webservice.swift
    
    import UIKit
    import Alamofire
    import SwiftyJSON
    
    
    let BaseURL = WebserviceURLs.kBaseURL
    let baseTaskURL = WebserviceURLs.kBaseURL
    var request : Request!
    
    let header: [String:String] = ["key":"keyname"]
    
    //-------------------------------------------------------------
    // MARK: - Webservice For GetData Method
    //-------------------------------------------------------------
    
    func getData(_ dictParams: AnyObject, nsURL: String,  completion: @escaping (_ result: AnyObject ,_ success: Bool) -> Void)
{
    let url = WebserviceURLs.kBaseURL + nsURL
    
    
    Alamofire.request(url, method: .get, parameters: dictParams as? [String : AnyObject], encoding: URLEncoding.default, headers: header)
    .validate()
    .responseJSON
    { (response) in
    
    
    if let JSON = response.result.value
    {
    
    if (JSON as AnyObject).object(forKey:("status")) as? Bool == false
    {
    completion(JSON as AnyObject, false)
    }
    else
    {
    completion(response.data as AnyObject, true)
    }
    }
    else
    {
    print("Data not Found")
    }
    }
    }
    
    //-------------------------------------------------------------
    // MARK: - Webservice For Send Image Method
    //-------------------------------------------------------------
    
    func sendImage(_ dictParams: AnyObject, image1: UIImage, nsURL: String, completion: @escaping (_ result: AnyObject, _ success: Bool) -> Void) {
    
    let url = WebserviceURLs.kBaseURL + nsURL
    
    
    let dictData = dictParams as! [String:AnyObject]
    Alamofire.upload(multipartFormData: { (multipartFormData) in
    
    
    if let imageData1 = UIImage.jpegData(image1)(compressionQuality: 0.3) {
    
    multipartFormData.append(imageData1, withName: "image", fileName: "image.jpeg", mimeType: "image/jpeg")
    }
    
    for (key, value) in dictData
    {
    
    print(value)
    multipartFormData.append(String(describing: value).data(using: .utf8)!, withName: key)
    }
    }, usingThreshold: 10 * 1024 * 1024, to: url, method: .post, headers: header) { (encodingResult) in
    switch encodingResult
    {
    case .success(let upload, _, _):
    request =  upload.responseJSON {
    response in
    
    if let JSON = response.result.value {
    
    if ((JSON as AnyObject).object(forKey: "status") as! Bool) == true
    {
    completion(response.data as AnyObject, true)
    print("If JSON")
    
    }
    else
    {
    completion(JSON as AnyObject, false)
    print("else JSON")
    }
    }
    else
    {
    print("ERROR")
    }
    
    
    }
    case .failure( _):
    print("failure")
    
    break
    }
    }
    }
    
    //-------------------------------------------------------------
    // MARK: - Webservice For post without hud
    //-------------------------------------------------------------
    
    
    func postDataWithoutHud(_ dictParams: AnyObject, nsURL: String, completion: @escaping (_ result: AnyObject, _ sucess: Bool) -> Void)
{
    let url = WebserviceURLs.kBaseURL + nsURL
    print("url = \(url) params = \(dictParams)")
    
    
    Alamofire.request(url, method: .post, parameters: dictParams as? [String : AnyObject], encoding: URLEncoding.default, headers: header)
    .validate()
    .responseJSON
    { (response) in
    
    
    switch response.result
    {
    case .success(let _):
    if let JSON = response.result.value
    {
    if (JSON as AnyObject).object(forKey:("status")) as? Bool == false
    {
    completion(JSON as AnyObject, false)
    }
    else
    {
    completion(response.data as AnyObject, true)
    }
    }
    else {
    completion(response.result.value as AnyObject, false)
    
    }
    case .failure(_): break
    
    }
    }
    }
    
    //-------------------------------------------------------------
    // MARK: - Webservice For Send Image Method
    //-------------------------------------------------------------
    
    func postTwoImageMethod(_ dictParams: [String:AnyObject], image1: UIImage, image2: UIImage, nsURL: String, completion: @escaping (_ result: AnyObject, _ success: Bool) -> Void) {
    
    let url = WebserviceURLs.kBaseURL + nsURL
    
    
    Alamofire.upload(multipartFormData: { (multipartFormData) in
    
    
    
    if let imageData1 = UIImage.jpegData(image1)(compressionQuality: 0.3){
    
    multipartFormData.append(imageData1, withName: "Image", fileName: "image.png", mimeType: "image/png")
    }
    if let imageData2 = image2.jpegData(compressionQuality: 0.6){
    multipartFormData.append(imageData2, withName: "Passport", fileName: "image.png", mimeType: "image/png")
    }
    
    for (key, value) in dictParams
    {
    
    print(value)
    multipartFormData.append((value as! String).data(using: String.Encoding.utf8)!, withName: key )
    
    }
    }, usingThreshold: 10 * 1024 * 1024, to: url, method: .post, headers: header) { (encodingResult) in
    switch encodingResult
    {
    case .success(let upload, _, _):
    request =  upload.responseJSON {
    response in
    
    if let JSON = response.result.value {
    
    if ((JSON as AnyObject).object(forKey: "status") as! Bool) == true
    {
    completion(JSON as AnyObject, true)
    print("If JSON")
    
    }
    else
    {
    completion(JSON as AnyObject, false)
    print("else JSON")
    }
    }
    else
    {
    print("ERROR")
    }
    
    
    }
    case .failure( _):
    print("failure")
    break
    }
    }
    }
    ////////////////////////////////subclass///////////////////////////////////////////
    
    import UIKit
    import Alamofire
    import SwiftyJSON
    
    let InIt = WebserviceURLs.kInit
    let logindata = WebserviceURLs.klogin //DONE
    let Register = WebserviceURLs.kRegister //DONE
    
    //————————————————————————————
    // MARK: - Webservice For SendMessage
    //-------------------------------------------------------------
    func webservicename(_ dictParams: AnyObject, completion: @escaping(_ result: AnyObject, _ success: Bool) -> Void)
{
    let url = kfull urlname
    postData(dictParams, nsURL: url, completion: completion)
    }
    //-------------------------------------------------------------
    // MARK: - Webservice Advertisements
    //-------------------------------------------------------------
    
    func webservicename(completion: @escaping(_ result: AnyObject, _ success: Bool) -> Void)
{
    let url = full urlname
    getData([] as AnyObject, nsURL: url, completion: completion)
    }
    
    
    //-------------------------------------------------------------
    // MARK: - Webservice For Save profile
    //-------------------------------------------------------------
    func webservicename(_ dictParams: AnyObject, image1: UIImage, completion: @escaping(_ result: AnyObject, _ success: Bool) -> Void)
{
    let url = Saveimage
    sendImage(dictParams, image1: image1, nsURL: url, completion: completion)
    }
    
    
    ////////////////////////////////////////// constant data //////////////////////////////////////
    
    import Foundation
    import UIKit
    
    //-------------------------------------------------------------
    // MARK: - WebserviceURLs
    //-------------------------------------------------------------
    struct WebserviceURLs {
    
    static let kBaseURL =  "base url"
    static let kBaseImageURL = "base image url"
    static let klogin = "rest_api/login"
    }
    struct keyAllKey
{
    static let kLoginData = "profile"
    static let id = "id"
    }
    
    func webserviceOFSendMessage()
{
    var dictdata = [String: AnyObject]()
    
    
    dictdata[keyAllKey.value] = txtvalue.text!.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines) as AnyObject
    
    
    webservicedata(dictdata as AnyObject) { (result, status) in
    if(status)
    {
    do {
    if let dictResponse = try JSONSerialization.jsonObject(with: result as! Data, options : .allowFragments) as? Dictionary<String,Any>
    {
    if let dictDataResponse = dictResponse as? [String:AnyObject]
    {
    if let dictData = dictDataResponse["message_data"] as? [String:AnyObject]
    {
    self.sendMessage(true, dictData: dictData)
    }
    }
    } else {
    print("bad json")
    }
    }
    catch let DecodingError.dataCorrupted(context) {
    print(context)
    } catch let DecodingError.keyNotFound(key, context) {
    print("Key '\(key)' not found:", context.debugDescription)
    print("codingPath:", context.codingPath)
    } catch let DecodingError.valueNotFound(value, context) {
    print("Value '\(value)' not found:", context.debugDescription)
    print("codingPath:", context.codingPath)
    } catch let DecodingError.typeMismatch(type, context)  {
    print("Type '\(type)' mismatch:", context.debugDescription)
    print("codingPath:", context.codingPath)
    } catch {
    print("error: ", error)
    
    }
    }
    
    }
    }
    
    ///////////////////////////////////////seguedata /////////////////////////////////////
    
    if(segue.identifier == "SegueToscreen name”)
    {
    
    let data = segue.destination as!  ViewControllername
    
    if let indexPath = sender as? IndexPath{
    let senderid = array[indexPath.row]
    
    data.strSendId = pass data name
    }
    }
    ///////////////////////////////////// Table view cell animation/////////////////////////////////////
    
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
    cell.alpha = 0.0
    let transform = CATransform3DTranslate(CATransform3DIdentity, -250 , 20 , 0)
    cell.layer.transform = transform
    
    
    
    UIView.animate(withDuration: 2.0) {
    cell.alpha = 1.0
    cell.layer.transform = CATransform3DIdentity
    }
    }
    ////////////////////////////////////////// web service file //////////////////////////////////////
    //  WebserviceMainClass.swift
    
    import UIKit
    import Alamofire
    import SwiftyJSON
    
    
    let BaseURL = WebserviceURLs.kBaseURL
    let baseTaskURL = WebserviceURLs.kBaseURL
    var request : Request!
    
    let header: [String:String] = ["key":"headerkey"]
    
    
    //-------------------------------------------------------------
    // MARK: - Webservice For GetData Method
    //-------------------------------------------------------------
    
    func getData(_ dictParams: AnyObject, nsURL: String,  completion: @escaping (_ result: AnyObject ,_ success: Bool) -> Void)
{
    let url = WebserviceURLs.kBaseURL + nsURL
    
    
    Alamofire.request(url, method: .get, parameters: dictParams as? [String : AnyObject], encoding: URLEncoding.default, headers: header)
    .validate()
    .responseJSON
    { (response) in
    
    
    if let JSON = response.result.value
    {
    
    if (JSON as AnyObject).object(forKey:("status")) as? Bool == false
    {
    completion(JSON as AnyObject, false)
    }
    else
    {
    completion(response.data as AnyObject, true)
    }
    }
    else
    {
    print("Data not Found")
    }
    }
    }
    
    //-------------------------------------------------------------
    // MARK: - Webservice For Send Image Method
    //-------------------------------------------------------------
    
    func sendImage(_ dictParams: AnyObject, image1: UIImage, nsURL: String, completion: @escaping (_ result: AnyObject, _ success: Bool) -> Void) {
    
    let url = WebserviceURLs.kBaseURL + nsURL
    
    
    let dictData = dictParams as! [String:AnyObject]
    Alamofire.upload(multipartFormData: { (multipartFormData) in
    
    
    if let imageData1 = UIImage.jpegData(image1)(compressionQuality: 0.3) {
    
    multipartFormData.append(imageData1, withName: "image", fileName: "image.jpeg", mimeType: "image/jpeg")
    }
    
    for (key, value) in dictData
    {
    
    print(value)
    multipartFormData.append(String(describing: value).data(using: .utf8)!, withName: key)
    }
    }, usingThreshold: 10 * 1024 * 1024, to: url, method: .post, headers: header) { (encodingResult) in
    switch encodingResult
    {
    case .success(let upload, _, _):
    request =  upload.responseJSON {
    response in
    
    if let JSON = response.result.value {
    
    if ((JSON as AnyObject).object(forKey: "status") as! Bool) == true
    {
    completion(response.data as AnyObject, true)
    print("If JSON")
    
    }
    else
    {
    completion(JSON as AnyObject, false)
    print("else JSON")
    }
    }
    else
    {
    print("ERROR")
    }
    
    
    }
    case .failure( _):
    print("failure")
    
    break
    }
    }
    }
    
    //-------------------------------------------------------------
    // MARK: - Webservice For post without hud
    //-------------------------------------------------------------
    
    
    func postDataWithoutHud(_ dictParams: AnyObject, nsURL: String, completion: @escaping (_ result: AnyObject, _ sucess: Bool) -> Void)
{
    let url = WebserviceURLs.kBaseURL + nsURL
    print("url = \(url) params = \(dictParams)")
    
    
    Alamofire.request(url, method: .post, parameters: dictParams as? [String : AnyObject], encoding: URLEncoding.default, headers: header)
    .validate()
    .responseJSON
    { (response) in
    
    
    switch response.result
    {
    case .success(let _):
    if let JSON = response.result.value
    {
    if (JSON as AnyObject).object(forKey:("status")) as? Bool == false
    {
    completion(JSON as AnyObject, false)
    }
    else
    {
    completion(response.data as AnyObject, true)
    }
    }
    else {
    completion(response.result.value as AnyObject, false)
    
    }
    case .failure(_): break
    
    }
    
    
    }
    }
    
    //-------------------------------------------------------------
    // MARK: - Webservice For Send Image Method
    //-------------------------------------------------------------
    
    func postTwoImageMethod(_ dictParams: [String:AnyObject], image1: UIImage, image2: UIImage, nsURL: String, completion: @escaping (_ result: AnyObject, _ success: Bool) -> Void) {
    
    let url = WebserviceURLs.kBaseURL + nsURL
    
    
    Alamofire.upload(multipartFormData: { (multipartFormData) in
    
    
    
    if let imageData1 = UIImage.jpegData(image1)(compressionQuality: 0.3){
    
    multipartFormData.append(imageData1, withName: "Image", fileName: "image.png", mimeType: "image/png")
    }
    if let imageData2 = image2.jpegData(compressionQuality: 0.6){
    multipartFormData.append(imageData2, withName: "Passport", fileName: "image.png", mimeType: "image/png")
    }
    
    for (key, value) in dictParams
    {
    
    print(value)
    multipartFormData.append((value as! String).data(using: String.Encoding.utf8)!, withName: key )
    
    }
    }, usingThreshold: 10 * 1024 * 1024, to: url, method: .post, headers: header) { (encodingResult) in
    switch encodingResult
    {
    case .success(let upload, _, _):
    request =  upload.responseJSON {
    response in
    
    if let JSON = response.result.value {
    
    if ((JSON as AnyObject).object(forKey: "status") as! Bool) == true
    {
    completion(JSON as AnyObject, true)
    print("If JSON")
    
    }
    else
    {
    completion(JSON as AnyObject, false)
    print("else JSON")
    }
    }
    else
    {
    print("ERROR")
    }
    
    
    }
    case .failure( _):
    print("failure")
    break
    }
    }
    }
    ////////////////////////////////subclass///////////////////////////////////////////
    
    import UIKit
    import Alamofire
    import SwiftyJSON
    
    let InIt = WebserviceURLs.kInit
    let logindata = WebserviceURLs.klogin //DONE
    let loginWithLinkedin = WebserviceURLs.kloginWithLinkdin
    let Register = WebserviceURLs.kRegister //DONE
    let MyInterests = WebserviceURLs.kMyInterests //DONE
    
    //————————————————————————————
    // MARK: - Webservice For SendMessage
    //-------------------------------------------------------------
    func websericename(_ dictParams: AnyObject, completion: @escaping(_ result: AnyObject, _ success: Bool) -> Void)
{
    let url = kLogout
    postData(dictParams, nsURL: url, completion: completion)
    }
    //-------------------------------------------------------------
    // MARK: - Webservice Advertisements
    //-------------------------------------------------------------
    
    func websericename(completion: @escaping(_ result: AnyObject, _ success: Bool) -> Void)
{
    let url = kAdvertise
    getData([] as AnyObject, nsURL: url, completion: completion)
    }
    
    
    //-------------------------------------------------------------
    // MARK: - Webservice For Save profile
    //-------------------------------------------------------------
    func webserviceOfSaveProfile(_ dictParams: AnyObject, image1: UIImage, completion: @escaping(_ result: AnyObject, _ success: Bool) -> Void)
{
    let url = SaveProfile
    sendImage(dictParams, image1: image1, nsURL: url, completion: completion)
}
    
    
    ////////////////////////////////////////// constant data //////////////////////////////////////
    
    import Foundation
    import UIKit
    
    //-------------------------------------------------------------
    // MARK: - WebserviceURLs
    //-------------------------------------------------------------
    struct WebserviceURLs {
    
    static let kBaseURL =  "base url"
    static let kBaseImageURL = "base image url"
    static let kInit = "rest_api/init"
    static let klogin = "rest_api/login"
    }
    
struct keyAllKey
{
    static let kLoginData = "profile"
    static let id = "id"
}
    
    func webserviceOFSendMessage()
{
    var dictdata = [String: AnyObject]()
    let data = SingltonClass.sharedInstance.ProfileLoginData!
    let IdOfUser =  data.profiledata!.id!
    dictdata[keyAllKey.senderUser] = IdOfUser as AnyObject//id
    dictdata[keyAllKey.receiverUser] = strSendId as AnyObject//id
    dictdata[keyAllKey.message] = txtMessage.text!.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines) as AnyObject
    
    
    webserviceOfSendMessage(dictdata as AnyObject) { (result, status) in
    if(status)
    {
    do {
    if let dictResponse = try JSONSerialization.jsonObject(with: result as! Data, options : .allowFragments) as? Dictionary<String,Any>
    {
    if let dictDataResponse = dictResponse as? [String:AnyObject]
    {
    if let dictData = dictDataResponse["message_data"] as? [String:AnyObject]
    {
    
    self.delegateOfRefreshChatList?.RefreshChat()
    self.sendMessage(true, dictData: dictData)
    }
    }
    } else {
    print("bad json")
    }
    }
    catch let DecodingError.dataCorrupted(context) {
    print(context)
    } catch let DecodingError.keyNotFound(key, context) {
    print("Key '\(key)' not found:", context.debugDescription)
    print("codingPath:", context.codingPath)
    } catch let DecodingError.valueNotFound(value, context) {
    print("Value '\(value)' not found:", context.debugDescription)
    print("codingPath:", context.codingPath)
    } catch let DecodingError.typeMismatch(type, context)  {
    print("Type '\(type)' mismatch:", context.debugDescription)
    print("codingPath:", context.codingPath)
    } catch {
    print("error: ", error)
    
    }
    }
    }
}

